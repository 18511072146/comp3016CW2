//{{NO_DEPENDENCIES}}
// Microsoft Visual 
// 
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MODELTYPE                   129
#define IDC_CURSOR_ROTATION             131
#define IDD_DIALOG1                     134
#define IDD_FORM_COMMAND                150
#define IDC_FRAME_COLOR_BACK            1000
#define IDC_CHECK_ANTIALIAS             1001
#define IDC_CHECK_SMOOTH                1002
#define IDC_RADIO_MODEL_1               1003
#define IDC_RADIO_MODEL1                1003
#define IDC_CHECK_LIGHTING              1004
#define IDC_RADIO_MODEL_2               1005
#define IDC_RADIO_MODEL2                1005
#define IDC_RADIO_MODEL_0               1006
#define IDC_RADIO_MODEL0                1006
#define IDC_CHECK_VROTATION             1007
#define IDC_SLIDER_X                    1008
#define IDC_CHECK_LINK_SCALE            1009
#define IDC_FRAME_COLOR_LIGHT_AMBIENT   1010
#define IDC_SLIDER_Y                    1011
#define IDC_SLIDER_Z                    1012
#define IDC_FRAME_COLOR_LIGHT_AMBIENT2  1013
#define IDC_FRAME_COLOR_LIGHT_AMBIENT3  1014
#define IDC_SLIDER_L1_ROTATION          1018
#define IDC_SLIDER_LIGHT_ROTATION       1018
#define IDC_SLIDER_L1_DEPRESSION        1019
#define IDC_SLIDER_LIGHT_DEPRESSION     1019
#define IDC_SLIDER_L1_DISTANCE          1020
#define IDC_SLIDER_LIGHT_DISTANCE       1020
#define IDC_SLIDER_L2_ROTATION          1021
#define IDC_SLIDER_L2_DEPRESSION        1022
#define IDC_SLIDER_L2_DISTANCE          1023
#define IDC_CHECK_L1_SPOT               1024
#define IDC_CHECK_LIGHT_SPOT            1024
#define IDC_CHECK_L2_SPOT               1025
#define IDC_SLIDER1                     1026
#define IDC_SLIDER_MAT_SHININESS        1026
#define IDC_CHECK_CENTERS               1027
#define IDC_CHECK_EDGES                 1028
#define IDC_CHECK_VERTEXES              1029
#define IDC_CHECK_ROTATION_LIMIT        1030
#define IDC_CHECK1                      1031
#define IDC_CHECK_TEXTURES              1031
#define ID_GRID                         32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
